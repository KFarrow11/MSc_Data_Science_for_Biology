# Share of one-year-olds vaccinated against measles - Data package

This data package contains the data that powers the chart ["Share of one-year-olds vaccinated against measles"](https://ourworldindata.org/grapher/share-of-children-vaccinated-against-measles?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on April 29, 2025.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Share of one-year-olds who have received their first dose of measles-containing vaccine (MCV1)
The percentage of one-year-olds who have received their first dose of measles-containing vaccine (MCV1) in a given year.
Last updated: December 10, 2024  
Next update: December 2025  
Date range: 1980–2023  
Unit: %  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
WHO & UNICEF (2024) – processed by Our World in Data

#### Full citation
WHO & UNICEF (2024) – processed by Our World in Data. “Share of one-year-olds who have received their first dose of measles-containing vaccine (MCV1)” [dataset]. WHO & UNICEF, “WHO Immunization Data - Vaccination coverage” [original data].
Source: WHO & UNICEF (2024) – processed by Our World In Data

### What you should know about this data
* This data includes estimates for all WHO Member States, including those that did not report 2023 data. For non-reporting countries, estimates were extrapolated from the last point informed by empirical data.
* To calculate global and regional average, values are extrapolated from 2022 for non-reporting countries. Non-reporting countries represent approximately 5% of the 2023 cohort.
* These estimates are based on quantitative data: 1) Country reported coverage data (official and administrative coverage) and 2) Survey coverage (from survey final reports, and complying with minimum set of quality criteria), and are informed by contextual information (e.g., stock-outs, changes in schedule, and other relevant information where available and appropriate). These estimates are affected by the availability and quality of the underlying data.
* In countries where the national schedule recommends their first dose measles vaccine at 12 months or later based on the epidemiology of disease in the country, these estimates reflect the percentage of children who received their first dose of measles vaccine as recommended.

### Source

#### WHO & UNICEF – WHO Immunization Data - Vaccination coverage
Retrieved on: 2024-12-10  
Retrieved from: https://immunizationdata.who.int/global?topic=Vaccination-coverage&location=  


    